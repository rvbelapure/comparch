#include <stdint.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <map>
#include <set>
#include <assert.h>
#include <zlib.h>

#define UINT64 uint64_t 

#define ADDRINT uint64_t 
#define INS uint64_t 

using namespace std; 




