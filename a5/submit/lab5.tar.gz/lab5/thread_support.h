#define HW_MAX_THREAD 4   // add this line
